# VégéScan v5 — interface moderne

Version modernisée de VégéScan avec :
- interface responsive moderne
- reconnaissance Pl@ntNet
- jusqu’à 5 photos d’une même plante
- résultats alternatifs et score de confiance
- module d’observation maladies & ravageurs
- potager, calendrier, lune et météo (modules d’interface)

## Déploiement Render
Build Command :
`mkdir -p app && unzip -o vegescan-modern-v5.zip -d app && cd app/vegescan-v5 && npm install && npm run build`

Start Command :
`cd app/vegescan-v5 && node server/index.mjs`

Variable d’environnement : `PLANTNET_API_KEY`

## Conseils particuliers ↔ professionnel
Pour activer la boîte de réception professionnelle, ajoutez dans Render une variable d'environnement :
- `VEGESCAN_PRO_CODE` = un code secret de votre choix.

Les particuliers peuvent envoyer une demande via « Demander conseil ». Les demandes arrivent dans « Conseils à traiter » après passage en mode Professionnel et saisie du code. Le bouton e-mail permet d'ouvrir le logiciel de messagerie du professionnel pour répondre au particulier.

> Prototype V7 : les demandes sont conservées en mémoire du serveur. Une prochaine version pourra utiliser une vraie base de données persistante et des notifications e-mail automatiques.
