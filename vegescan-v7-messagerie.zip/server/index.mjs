import express from 'express';
import multer from 'multer';
import crypto from 'crypto';
const app=express();
const upload=multer({storage:multer.memoryStorage(),limits:{files:5,fileSize:10*1024*1024}});
const PORT=process.env.PORT||3000,KEY=process.env.PLANTNET_API_KEY,PRO_CODE=process.env.VEGESCAN_PRO_CODE;
const advice=[];
app.use(express.json({limit:'1mb'}));
app.post('/api/identify',upload.array('images',5),async(req,res)=>{
 if(!KEY)return res.status(503).json({error:'PLANTNET_API_KEY missing'});
 if(!req.files?.length)return res.status(400).json({error:'images missing'});
 const form=new FormData();
 for(const file of req.files) form.append('images',new Blob([file.buffer],{type:file.mimetype}),file.originalname);
 form.append('organs','auto');
 const url=`https://my-api.plantnet.org/v2/identify/all?lang=fr&nb-results=5&api-key=${encodeURIComponent(KEY)}`;
 try{const r=await fetch(url,{method:'POST',body:form});const d=await r.json();if(!r.ok)return res.status(r.status).json(d);const top=d.results?.[0];res.json({analysisId:crypto.randomUUID(),bestMatch:d.bestMatch,scientificName:top?.species?.scientificName||d.bestMatch,commonName:top?.species?.commonNames?.[0]||d.bestMatch,score:top?.score||0,alternatives:(d.results||[]).slice(0,5).map(x=>({name:x.species?.scientificName,common:x.species?.commonNames?.[0],score:x.score}))});}
 catch(e){console.error('Pl@ntNet error',e.message);res.status(500).json({error:'upstream_error'});}
});
function checkPro(req,res){if(!PRO_CODE)return res.status(503).json({error:'VEGESCAN_PRO_CODE missing'});if(req.get('x-pro-code')!==PRO_CODE)return res.status(401).json({error:'invalid_pro_code'});return true;}
app.post('/api/advice',(req,res)=>{const {name,email,question,topic,plant,confidence,hasPhoto,photoName,date}=req.body||{};if(!email||!question)return res.status(400).json({error:'email_and_question_required'});const item={id:`adv-${crypto.randomUUID()}`,name:name||'Visiteur',email,question,topic:topic||'Autre',plant:plant||'',confidence:Number(confidence)||0,hasPhoto:Boolean(hasPhoto),photoName:photoName||'',date:date||new Date().toISOString(),status:'nouvelle',reply:''};advice.unshift(item);if(advice.length>500)advice.pop();res.status(201).json({request:item});});
app.get('/api/advice',(req,res)=>{if(checkPro(req,res)!==true)return;res.json({requests:advice});});
app.patch('/api/advice/:id',(req,res)=>{if(checkPro(req,res)!==true)return;const item=advice.find(x=>x.id===req.params.id);if(!item)return res.status(404).json({error:'not_found'});item.reply=String(req.body?.reply||'').trim();item.status=item.reply?'répondue':'nouvelle';item.repliedAt=item.reply?new Date().toISOString():null;res.json({request:item});});
app.get('/api/health',(req,res)=>res.json({ok:true,plantnetConfigured:Boolean(KEY),adviceConfigured:Boolean(PRO_CODE)}));
app.use(express.static('dist'));
app.listen(PORT,()=>console.log(`VégéScan server on ${PORT}`));
