# VégéScan — Pack consolidé de déploiement

Cette archive regroupe en un seul ZIP le projet VégéScan disponible dans le dossier de travail au moment de sa préparation, avec la bannière botanique V24.2.

## Fonctions présentes dans le code fourni
- Accueil Botanique Élégant et navigation responsive
- Reconnaissance Pl@ntNet (jusqu'à 5 photos, résultats et alternatives)
- Comparaison des candidats avec les validations professionnelles présentes dans `corrections` (si Supabase est configuré)
- Demande de correction et validation professionnelle, édition des corrections
- Base de connaissances professionnelle
- Mon jardin (stockage local du navigateur dans cette version)
- Communauté (publications Supabase)
- Demandes de conseils et boîte de réception professionnelle

## Fonctions non incluses comme fonctionnalités finalisées
- Diagnostic automatique fiable des maladies : non implémenté dans cette archive
- Encyclopédie horticole exhaustive et vérifiée : non implémentée
- Synchronisation multi-appareils du jardin personnel : le jardin est stocké localement dans le navigateur
- Entraînement d'un modèle IA : les correspondances professionnelles sont une recherche/comparaison, elles ne réentraînent pas Pl@ntNet

## Variables d'environnement Render
Conserver les noms et valeurs déjà configurés :
- `PLANTNET_API_KEY`
- `VEGESCAN_PRO_KEY`
- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `RESEND_API_KEY` (optionnelle)
- `RESEND_FROM_EMAIL` (optionnelle)

## Commandes Render
Build Command :
```bash
npm install && npm run build
```
Start Command :
```bash
node server/index.mjs
```

L'application sert le dossier `dist` via Express après compilation Vite.

## Vérifications effectuées lors de la préparation
- Archive ZIP créée à partir du projet consolidé disponible.
- Vérification syntaxique du serveur Node.js (`node --check server/index.mjs`).
- La compilation Vite n'a pas pu être confirmée dans l'environnement de préparation : `npm install` a dépassé le délai disponible. Vérifier les logs Render avant de remplacer la version en production.

Faire une sauvegarde du déploiement actuel avant mise en production. Ne pas supprimer les anciennes archives de sauvegarde.
