# VégéScan V24.2 — Bannière botanique

Cette mise à jour remplace la photo sombre de fougères de l'accueil par une composition botanique lumineuse créée pour VégéScan : fond crème, feuillages variés, branches d'olivier, eucalyptus et fleurs claires.

Le changement porte uniquement sur l'image de la bannière d'accueil. Les écrans, appels API, intégrations Pl@ntNet/Supabase et données ne sont pas modifiés.

## Déploiement Render
Conserver les variables d'environnement et le Start Command existants. Déposer cette archive à la racine du dépôt GitHub puis utiliser le Build Command indiqué dans les instructions de déploiement.
