# VégéScan V10 — version simplifiée

Cette version conserve la base persistante de V9 et simplifie l’interface de première mise à disposition : les modules météo, calendrier de culture et maladies/ravageurs sont masqués. Le calendrier lunaire, le potager, la reconnaissance et les conseils professionnels restent disponibles.

## Variables Render
- `PLANTNET_API_KEY` : clé Pl@ntNet existante
- `VEGESCAN_PRO_KEY` : code professionnel existant
- `SUPABASE_URL` : URL du projet Supabase
- `SUPABASE_SERVICE_ROLE_KEY` : clé service_role Supabase, uniquement côté serveur
- `RESEND_API_KEY` : optionnelle, pour les e-mails de réponse
- `RESEND_FROM_EMAIL` : optionnelle, adresse expéditrice validée chez Resend

## Base de données
Dans Supabase > SQL Editor, exécuter `supabase-schema.sql`.

Sans Supabase, l'application garde un stockage mémoire de secours, mais celui-ci n'est pas permanent après redémarrage.


## V11 – Communauté
- Bibliothèque communautaire de photos
- Nom/pseudo affiché avec chaque publication
- Prévue pour évoluer vers publication privée/publique, recherche et validation professionnelle.


## V12 corrigée – Bibliothèque visible
La bibliothèque est intégrée à la navigation et permet de publier une plante avec pseudo, description, photo (sélection locale), visibilité public/privé et recherche. Cette étape valide l'interface; le stockage Supabase Storage des fichiers photo sera une étape dédiée.


## V13 – Mon jardin
- Remplace la liste fixe par un jardin personnel
- Ajout d'une plante avec variété, date, notes et photo
- Fiche détaillée
- Suivi de croissance par ajout de photos


## V13 corrigée – Mon jardin
Le menu Mes plantes affiche maintenant le nouveau jardin personnel avec ajout, fiche plante et suivi photo.
