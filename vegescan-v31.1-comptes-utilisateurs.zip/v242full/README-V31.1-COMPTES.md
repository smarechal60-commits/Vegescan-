# VégéScan V31.1 — Comptes utilisateurs

Cette version ajoute un écran « Mon compte » avec inscription e-mail/mot de passe, connexion, déconnexion et demande de réinitialisation du mot de passe via Supabase Auth.

## Avant déploiement
1. Dans Supabase SQL Editor, exécuter `supabase-v31-auth.sql` sur le projet existant. Le script crée uniquement la table de profils et son déclencheur; il ne supprime aucune donnée existante.
2. Dans Supabase Authentication > URL Configuration, configurer l'URL du site `https://vegescan.onrender.com` et les URL de redirection autorisées.
3. Dans Supabase Authentication > Providers > Email, choisir si la confirmation d'e-mail est activée. Si elle l'est, le nouvel utilisateur doit confirmer son adresse avant la connexion.
4. Dans Render > Environment, ajouter les variables de build `VITE_SUPABASE_URL` (même URL que `SUPABASE_URL`) et `VITE_SUPABASE_ANON_KEY` (clé publique anon/publishable du projet). Ne jamais utiliser `SUPABASE_SERVICE_ROLE_KEY` dans une variable VITE ou dans le navigateur.
5. Redéployer pour que Vite intègre ces variables.

## Render
Build Command : `npm install && npm run build`
Start Command : `node server/index.mjs`

## Portée et limites de V31.1
- L'essai de 14 jours est créé dans la base à l'inscription via un trigger SQL.
- L'écran affiche la date de fin de l'essai lorsqu'un profil est disponible.
- Cette version ne met pas encore en place le contrôle serveur des fonctions Premium, Stripe, les webhooks de paiement, ni la bascule automatique sécurisée vers le plan gratuit. Ces éléments sont les étapes V31.2/V31.3.
- La session Supabase est stockée localement dans le navigateur pour ce premier jalon. Avant de commercialiser Premium, compléter le rafraîchissement/expiration de session et vérifier les droits côté serveur.
- Les fonctions existantes sont conservées; l'authentification n'est pas imposée à l'ensemble de l'application dans cette étape.
