# VégéScan V30.1 — améliorations pratiques

Cette version reprend le pack V30 et ajoute :
- ajout direct d'une identification au jardin personnel ;
- conservation locale de la photo d'une plante (si le fichier fait moins de 1,8 Mo) ;
- ajout de photos aux plantes du jardin avec aperçu ;
- recherche dans Mon jardin ;
- export JSON de sauvegarde du jardin ;
- boutons d'action des résultats adaptés aux petits écrans.

Les données du jardin restent locales au navigateur/téléphone. L'export JSON permet d'en faire une sauvegarde ; il ne synchronise pas le jardin entre appareils.

## Render
Archive conçue avec les fichiers du projet directement à la racine du ZIP (pas de dossier parent supplémentaire).
Build Command, depuis le répertoire de service où se trouve l'archive :
`rm -rf app && mkdir app && unzip -o vegescan-v30.1-ameliorations.zip -d app && cd app && npm install && npm run build`
Start Command :
`cd app && node server/index.mjs`
Conserver les variables d'environnement existantes. Vérifier les logs de build et le démarrage avant de considérer le déploiement validé.
