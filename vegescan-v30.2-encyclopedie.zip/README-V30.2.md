# VégéScan V30.2 — Encyclopédie végétale

Cette version ajoute une rubrique Encyclopédie accessible depuis le menu latéral et l'accueil.

## Fonctionnalités
- Recherche par nom commun, nom botanique et famille.
- Filtres par type de plante.
- Fiches détaillées avec exposition, arrosage, sol, floraison, rusticité, hauteur et conseils généraux.
- Mise en page responsive, assortie à l'identité Botanique Élégant.

## Important
Les 8 fiches intégrées constituent une première sélection éditoriale et des indications générales. Les besoins peuvent varier selon cultivar, région et conditions de culture. Les données ne sont pas présentées comme des recommandations personnalisées ni comme des validations professionnelles.

## Déploiement Render
Build Command :
`rm -rf app && mkdir app && unzip -o vegescan-v30.2-encyclopedie.zip -d app && cd app && npm install && npm run build`

Start Command :
`cd app && node server/index.mjs`

Conserver les variables d'environnement existantes. Sauvegarder la version actuellement en production avant déploiement. Compilation à confirmer dans les logs Render.
