import express from 'express';
import multer from 'multer';
const app=express();
const upload=multer({storage:multer.memoryStorage(),limits:{files:5,fileSize:10*1024*1024}});
const PORT=process.env.PORT||3000, KEY=process.env.PLANTNET_API_KEY;
const PRO_KEY=process.env.VEGESCAN_PRO_KEY;
const SUPABASE_URL=(process.env.SUPABASE_URL||'').replace(/\/$/,'');
const SUPABASE_KEY=process.env.SUPABASE_SERVICE_ROLE_KEY||'';
const RESEND_KEY=process.env.RESEND_API_KEY||'';
const RESEND_FROM=process.env.RESEND_FROM_EMAIL||'';
const memoryRequests=[];
const memoryCorrections=[];
const dbReady=Boolean(SUPABASE_URL&&SUPABASE_KEY);

async function db(path, options={}){
 const r=await fetch(`${SUPABASE_URL}/rest/v1/${path}`,{...options,headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${SUPABASE_KEY}`,'Content-Type':'application/json',Prefer:'return=representation',...(options.headers||{})}});
 const text=await r.text(); let data=null; try{data=text?JSON.parse(text):null}catch{}
 if(!r.ok) throw new Error(data?.message||data?.hint||`database_${r.status}`);
 return data;
}

app.post('/api/identify',upload.array('images',5),async(req,res)=>{
 if(!KEY)return res.status(503).json({error:'PLANTNET_API_KEY missing'});
 if(!req.files?.length)return res.status(400).json({error:'Ajoutez au moins une photo.'});
 const form=new FormData();
 // Pl@ntNet exige un organe pour chaque image envoyée, dans le même ordre.
 for(const file of req.files){
   const mime=(file.mimetype||'').toLowerCase();
   if(!['image/jpeg','image/png'].includes(mime)){
     return res.status(415).json({error:`Format non accepté par Pl@ntNet (${mime||'inconnu'}). Utilisez une photo JPG ou PNG.`});
   }
   form.append('images',new Blob([file.buffer],{type:mime}),file.originalname||`photo-${form.getAll('images').length+1}.${mime==='image/png'?'png':'jpg'}`);
   form.append('organs','auto');
 }
 const url=`https://my-api.plantnet.org/v2/identify/all?lang=fr&nb-results=5&api-key=${encodeURIComponent(KEY)}`;
 try{
   const r=await fetch(url,{method:'POST',body:form});
   const raw=await r.text(); let d={}; try{d=raw?JSON.parse(raw):{}}catch{d={message:raw}}
   if(!r.ok){console.error('Pl@ntNet response',r.status,d);return res.status(r.status).json({error:d.message||d.error||`Erreur Pl@ntNet (${r.status}). Vérifiez le format JPG/PNG et réessayez.`});}
   const top=d.results?.[0];
   res.json({bestMatch:d.bestMatch,scientificName:top?.species?.scientificName||d.bestMatch,commonName:top?.species?.commonNames?.[0]||d.bestMatch,score:top?.score||0,alternatives:(d.results||[]).slice(0,5).map(x=>({name:x.species?.scientificName,common:x.species?.commonNames?.[0],score:x.score}))});
 }catch(e){console.error('Pl@ntNet error',e.message);res.status(500).json({error:'Erreur de connexion au service Pl@ntNet. Réessayez dans quelques instants.'});}
});
app.use(express.json());
function requirePro(req,res,next){if(!PRO_KEY || req.get('x-vegescan-pro-key')!==PRO_KEY)return res.status(401).json({error:'professional_access_required'});next();}

app.post('/api/advice',async(req,res)=>{
 const {name,email,question,topic,plant,confidence}=req.body||{};
 if(!email||!question)return res.status(400).json({error:'email_and_question_required'});
 const item={id:`adv-${Date.now()}-${Math.random().toString(36).slice(2,7)}`,name:name||'Visiteur',email,question,topic:topic||'Autre',plant:plant||'',confidence:Number(confidence)||0,date:new Date().toISOString(),status:'nouvelle'};
 try{if(dbReady){const rows=await db('advice_requests',{method:'POST',body:JSON.stringify({id:item.id,name:item.name,email:item.email,question:item.question,topic:item.topic,plant:item.plant,confidence:item.confidence,status:item.status,date:item.date})});return res.status(201).json(rows[0]);} memoryRequests.unshift(item);res.status(201).json(item);}catch(e){console.error('Advice DB error',e.message);memoryRequests.unshift(item);res.status(201).json(item);}
});
app.get('/api/advice',requirePro,async(req,res)=>{try{if(dbReady)return res.json(await db('advice_requests?select=*&order=date.desc'));res.json(memoryRequests);}catch(e){console.error('Advice DB read error',e.message);res.json(memoryRequests);}});
app.post('/api/advice/:id/reply',requirePro,async(req,res)=>{
 const reply=req.body?.reply?.trim(); if(!reply)return res.status(400).json({error:'reply_required'});
 try{
  let item;
  if(dbReady){const rows=await db(`advice_requests?id=eq.${encodeURIComponent(req.params.id)}`,{method:'PATCH',body:JSON.stringify({reply,replied_at:new Date().toISOString(),status:'répondue'})});item=rows[0];}
  else {item=memoryRequests.find(x=>x.id===req.params.id);if(item){item.reply=reply;item.repliedAt=new Date().toISOString();item.status='répondue';}}
  if(!item)return res.status(404).json({error:'not_found'});
  if(RESEND_KEY&&RESEND_FROM){try{await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${RESEND_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:RESEND_FROM,to:[item.email],subject:'Réponse à votre demande VégéScan',html:`<p>Bonjour ${item.name||''},</p><p>${reply.replace(/\n/g,'<br>')}</p><p>🌿 L’équipe VégéScan</p>`})});}catch(e){console.error('Email error',e.message)}}
  res.json(item);
 }catch(e){console.error('Advice reply error',e.message);res.status(500).json({error:'reply_failed'});}
});

app.post('/api/corrections',upload.array('images',5),requirePro,async(req,res)=>{
 const {analysisId,suggestedName,scientificName,cultivar,note,country,producer}=req.body||{};
 if(!analysisId||!scientificName)return res.status(400).json({error:'analysis_and_species_required'});
 const id=`cor-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;
 const imageUrls=[];
 try{
  for(let i=0;i<(req.files||[]).length;i++){
   const file=req.files[i];
   const safe=(file.originalname||`photo-${i+1}.jpg`).replace(/[^a-zA-Z0-9._-]/g,'_');
   const path=`validated/${id}/${i+1}-${safe}`;
   const r=await fetch(`${SUPABASE_URL}/storage/v1/object/vegescan-training/${path}`,{method:'POST',headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${SUPABASE_KEY}`,'Content-Type':file.mimetype||'application/octet-stream','x-upsert':'true'},body:file.buffer});
   if(!r.ok)throw new Error(`training_storage_${r.status}`);
   imageUrls.push(`${SUPABASE_URL}/storage/v1/object/public/vegescan-training/${path}`);
  }
  const item={id,analysis_id:analysisId,suggested_name:suggestedName||'',scientific_name:scientificName,cultivar:cultivar||'',note:note||'',country:country||'',producer:producer||'',image_urls:imageUrls,date:new Date().toISOString()};
  if(dbReady){const rows=await db('corrections',{method:'POST',body:JSON.stringify(item)});return res.status(201).json(rows[0]);}
  memoryCorrections.unshift(item);res.status(201).json(item);
 }catch(e){console.error('Correction DB error',e.message);res.status(500).json({error:'correction_save_failed'});}
});
app.get('/api/corrections',requirePro,async(req,res)=>{try{if(dbReady)return res.json(await db('corrections?select=*&order=date.desc'));res.json(memoryCorrections);}catch(e){res.json(memoryCorrections);}});
app.get('/api/knowledge',requirePro,async(req,res)=>{try{if(dbReady)return res.json(await db('corrections?select=*&order=date.desc'));res.json(memoryCorrections);}catch(e){console.error('Knowledge read error',e.message);res.status(500).json({error:'knowledge_read_failed'});}});
app.patch('/api/corrections/:id',requirePro,async(req,res)=>{
 const allowed=['scientific_name','cultivar','note','country','producer'];
 const update={};
 for(const field of allowed) if(typeof req.body?.[field]==='string') update[field]=req.body[field].trim();
 if(!update.scientific_name) return res.status(400).json({error:'scientific_name_required'});
 try{
  if(dbReady){const rows=await db(`corrections?id=eq.${encodeURIComponent(req.params.id)}`,{method:'PATCH',body:JSON.stringify(update)});if(!rows?.length)return res.status(404).json({error:'correction_not_found'});return res.json(rows[0]);}
  const item=memoryCorrections.find(x=>x.id===req.params.id);if(!item)return res.status(404).json({error:'correction_not_found'});Object.assign(item,update);return res.json(item);
 }catch(e){console.error('Correction update error',e.message);res.status(500).json({error:'correction_update_failed'});}
});

app.get('/api/community',async(req,res)=>{
 try{if(dbReady)return res.json(await db('community_posts?select=*&visibility=eq.public&order=date.desc'));res.json([])}
 catch(e){console.error('Community DB read error',e.message);res.status(500).json({error:'community_read_failed'})}
});
app.post('/api/community',upload.single('photo'),async(req,res)=>{
 const {pseudo,plant,description,visibility}=req.body||{};
 if(!pseudo?.trim()||!plant?.trim())return res.status(400).json({error:'pseudo_and_plant_required'});
 if(!dbReady)return res.status(503).json({error:'database_not_configured'});
 const id=`post-${Date.now()}-${Math.random().toString(36).slice(2,7)}`;
 let photoUrl='',photoName=req.file?.originalname||'';
 try{
  if(req.file){
   const safeName=photoName.replace(/[^a-zA-Z0-9._-]/g,'_');
   const path=`community/${id}-${safeName}`;
   const r=await fetch(`${SUPABASE_URL}/storage/v1/object/vegescan-community/${path}`,{method:'POST',headers:{apikey:SUPABASE_KEY,Authorization:`Bearer ${SUPABASE_KEY}`,'Content-Type':req.file.mimetype||'application/octet-stream','x-upsert':'true'},body:req.file.buffer});
   if(!r.ok)throw new Error(`storage_${r.status}`);
   photoUrl=`${SUPABASE_URL}/storage/v1/object/public/vegescan-community/${path}`;
  }
  const item={id,pseudo:pseudo.trim(),plant:plant.trim(),description:(description||'').trim(),visibility:visibility==='private'?'private':'public',photo_name:photoName,photo_url:photoUrl,date:new Date().toISOString()};
  const rows=await db('community_posts',{method:'POST',body:JSON.stringify(item)});
  res.status(201).json(rows[0]);
 }catch(e){console.error('Community publish error',e.message);res.status(500).json({error:'community_publish_failed'})}
});


app.get('/api/health',(req,res)=>res.json({ok:true,plantnetConfigured:Boolean(KEY),databaseConfigured:dbReady,emailConfigured:Boolean(RESEND_KEY&&RESEND_FROM)}));
app.use(express.static('dist'));
app.listen(PORT,()=>console.log(`VégéScan server on ${PORT}`));
