-- VégéScan V31.1 : profils et essai gratuit de 14 jours
-- À exécuter dans Supabase > SQL Editor sur le projet existant.
-- Ne supprime aucune table ni donnée existante.
create table if not exists public.vegescan_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text not null default '',
  plan text not null default 'trial' check (plan in ('trial','free','premium_monthly','premium_yearly')),
  trial_started_at timestamptz not null default now(),
  trial_ends_at timestamptz not null default (now() + interval '14 days'),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.vegescan_profiles enable row level security;
drop policy if exists "Users can read their own VégéScan profile" on public.vegescan_profiles;
create policy "Users can read their own VégéScan profile"
  on public.vegescan_profiles for select to authenticated
  using (auth.uid() = id);

create or replace function public.vegescan_create_profile()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.vegescan_profiles (id,email,display_name,plan,trial_started_at,trial_ends_at)
  values (new.id,new.email,coalesce(new.raw_user_meta_data->>'display_name',''),'trial',now(),now()+interval '14 days')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created_vegescan on auth.users;
create trigger on_auth_user_created_vegescan
after insert on auth.users
for each row execute procedure public.vegescan_create_profile();

-- La table n'accorde aucun droit d'écriture au navigateur.
revoke all on public.vegescan_profiles from anon, authenticated;
grant select on public.vegescan_profiles to authenticated;
