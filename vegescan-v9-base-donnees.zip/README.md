# VégéScan V9 — conseils persistants

Cette version conserve le design V8 et ajoute une base persistante pour les demandes de conseil et les corrections professionnelles.

## Variables Render
- `PLANTNET_API_KEY` : clé Pl@ntNet existante
- `VEGESCAN_PRO_KEY` : code professionnel existant
- `SUPABASE_URL` : URL du projet Supabase
- `SUPABASE_SERVICE_ROLE_KEY` : clé service_role Supabase, uniquement côté serveur
- `RESEND_API_KEY` : optionnelle, pour les e-mails de réponse
- `RESEND_FROM_EMAIL` : optionnelle, adresse expéditrice validée chez Resend

## Base de données
Dans Supabase > SQL Editor, exécuter `supabase-schema.sql`.

Sans Supabase, l'application garde un stockage mémoire de secours, mais celui-ci n'est pas permanent après redémarrage.
