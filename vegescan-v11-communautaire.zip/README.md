# VégéScan V10 — version simplifiée

Cette version conserve la base persistante de V9 et simplifie l’interface de première mise à disposition : les modules météo, calendrier de culture et maladies/ravageurs sont masqués. Le calendrier lunaire, le potager, la reconnaissance et les conseils professionnels restent disponibles.

## Variables Render
- `PLANTNET_API_KEY` : clé Pl@ntNet existante
- `VEGESCAN_PRO_KEY` : code professionnel existant
- `SUPABASE_URL` : URL du projet Supabase
- `SUPABASE_SERVICE_ROLE_KEY` : clé service_role Supabase, uniquement côté serveur
- `RESEND_API_KEY` : optionnelle, pour les e-mails de réponse
- `RESEND_FROM_EMAIL` : optionnelle, adresse expéditrice validée chez Resend

## Base de données
Dans Supabase > SQL Editor, exécuter `supabase-schema.sql`.

Sans Supabase, l'application garde un stockage mémoire de secours, mais celui-ci n'est pas permanent après redémarrage.


## V11 – Communauté
- Bibliothèque communautaire de photos
- Nom/pseudo affiché avec chaque publication
- Prévue pour évoluer vers publication privée/publique, recherche et validation professionnelle.
