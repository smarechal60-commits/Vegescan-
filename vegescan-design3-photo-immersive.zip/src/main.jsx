import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import './style.css';

const cultures=[['🥕','Carotte','Semis mars → juillet','Récolte juin → novembre'],['🍅','Tomate','Semis février → avril','Récolte juin → octobre'],['🥬','Salade','Semis février → septembre','Récolte avril → novembre'],['🫛','Haricot','Semis mai → juillet','Récolte juillet → octobre'],['🥒','Courgette','Semis avril → juin','Récolte juin → octobre'],['🥔','Pomme de terre','Plantation mars → mai','Récolte juin → septembre']];

function App(){
 const [page,setPage]=useState('home'),[mode,setMode]=useState('particulier'),[files,setFiles]=useState([]),[result,setResult]=useState(null),[busy,setBusy]=useState(false),[history,setHistory]=useState([]),[corrections,setCorrections]=useState(()=>{try{return JSON.parse(localStorage.getItem('vegescan_corrections')||'[]')}catch{return[]}}),[adviceRequests,setAdviceRequests]=useState(()=>{try{return JSON.parse(localStorage.getItem('vegescan_advice_requests')||'[]')}catch{return[]}});
 const addFiles=e=>{const incoming=[...e.target.files].slice(0,5-files.length);setFiles(x=>[...x,...incoming])};
 const remove=i=>setFiles(x=>x.filter((_,n)=>n!==i));
 async function identify(){if(!files.length)return;setBusy(true);setPage('result');const fd=new FormData();files.forEach(f=>fd.append('images',f));
  try{const r=await fetch('/api/identify',{method:'POST',body:fd});const d=await r.json();if(!r.ok)throw Error(d.error||'error');d.analysisId=d.analysisId||`${Date.now()}`;setResult(d);setHistory(h=>[d,...h].slice(0,10));}catch(e){setResult({error:true,bestMatch:'Reconnaissance indisponible',scientificName:e.message||'Vérifiez la configuration du serveur.',score:0,alternatives:[]});}finally{setBusy(false)} }
 return <div className="shell">
  <aside className="sidebar"><div className="brand"><div className="brandmark">🌿</div><div><b>Végé<span>Scan</span></b><small>Identifiez • Protégez • Cultivez</small></div></div><div className="sideMode"><button className={mode==='particulier'?'active':''} onClick={()=>setMode('particulier')}>🏡 Particulier</button><button className={mode==='pro'?'active':''} onClick={()=>setMode('pro')}>🌾 Professionnel</button></div><Side onClick={setPage} icon="⌂" label="Accueil" id="home"/><Side onClick={setPage} icon="📷" label="Reconnaître une plante" id="scan"/><Side onClick={setPage} icon="🌱" label="Mes plantes" id="garden"/><Side onClick={setPage} icon="💬" label={mode==='pro'?'Conseils à traiter':'Demander conseil'} id={mode==='pro'?'inbox':'advice'}/><div className="sideBottom"><div className="miniCard"><b>Cultivons ensemble</b><span>un monde plus vert 🌿</span></div><small>VégéScan v1.0</small></div></aside>
  <main><header className="topbar"><div><span className="eyebrow">VOTRE COMPAGNON VÉGÉTAL</span><h1>{page==='home'?'Bonjour 👋':title(page)}</h1></div><div className="topActions"><button>🔔</button><button>⚙️</button><div className="avatar">S</div></div></header>
   {page==='home'&&<Home setPage={setPage} mode={mode}/>} 
   {page==='scan'&&<Scan files={files} addFiles={addFiles} remove={remove} identify={identify} busy={busy}/>} 
   {page==='result'&&<Result busy={busy} files={files} result={result} setPage={setPage} mode={mode} corrections={corrections} setCorrections={setCorrections}/>} 
   {page==='garden'&&<Garden/>}
   {page==='moon'&&<Moon/>}{page==='advice'&&<Advice result={result} files={files} onSubmit={async(req)=>{try{const r=await fetch('/api/advice',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(req)});if(!r.ok)throw Error();const saved=await r.json();setAdviceRequests(x=>[saved,...x].slice(0,100));}catch{const next=[req,...adviceRequests].slice(0,100);setAdviceRequests(next);localStorage.setItem('vegescan_advice_requests',JSON.stringify(next));}setPage('home')}}/>}{page==='inbox'&&<AdviceInbox requests={adviceRequests} setRequests={setAdviceRequests} corrections={corrections} mode={mode}/>} 
  </main><button className="floating" onClick={()=>setPage('scan')}>＋ <span>Nouvelle analyse</span></button>
 </div>
}
function title(p){return {scan:'Reconnaître une plante',result:'Résultat de l’analyse',garden:'Mes plantes',advice:'Demander conseil',inbox:'Conseils à traiter'}[p]}
function Side({onClick,icon,label,id}){return <button className="sideItem" onClick={()=>onClick(id)}><span>{icon}</span>{label}</button>}
function Home({setPage,mode}){return <div className="immersiveHome"><div className="immersiveShade"></div><div className="immersiveTop"><div className="immersiveBrand">🌿 <b>VégéScan</b></div><button className="ghostIcon">☰</button></div><div className="immersiveCenter"><span className="immersiveBadge">RECONNAISSANCE VÉGÉTALE</span><h2>Identifiez<br/><strong>vos plantes</strong></h2><p>Une photo suffit pour découvrir leur nom, leurs besoins et nos conseils.</p><button className="cameraCta" onClick={()=>setPage('scan')}><span>📷</span><small>Appuyez pour prendre une photo</small></button></div><div className="immersiveActions"><button onClick={()=>setPage('garden')}><span>🌱</span><b>Mes plantes</b></button><button onClick={()=>setPage('advice')}><span>💬</span><b>Conseils</b></button><button onClick={()=>setPage(mode==='pro'?'inbox':'advice')}><span>{mode==='pro'?'🌾':'✦'}</span><b>{mode==='pro'?'Espace Pro':'Plus'}</b></button></div><nav className="immersiveNav"><button className="active">⌂<small>Accueil</small></button><button onClick={()=>setPage('scan')}>⌾<small>Identifier</small></button><button onClick={()=>setPage('garden')}>♧<small>Mes plantes</small></button><button onClick={()=>setPage(mode==='pro'?'inbox':'advice')}>◌<small>Conseils</small></button></nav></div>}
function Tool({icon,title,text,onClick}){return <button className="tool" onClick={onClick}><span>{icon}</span><b>{title}</b><small>{text}</small><i>→</i></button>}
function Scan({files,addFiles,remove,identify,busy}){return <div className="content"><div className="scanGrid"><section className="upload panel"><div className="panelTitle"><div><span className="badge">PHOTO</span><h2>Ajoutez vos photos</h2><p>Jusqu’à 5 vues de la même plante pour améliorer l’identification.</p></div><span className="count">{files.length}/5</span></div><label className="drop"><span>📷</span><b>Cliquer pour ajouter une photo</b><small>ou glisser-déposer une image ici<br/>JPG, PNG, WEBP • 10 Mo max.</small><input type="file" accept="image/*" multiple onChange={addFiles}/></label>{files.length>0&&<div className="thumbs">{files.map((f,i)=><div className="thumb" key={i}><img src={URL.createObjectURL(f)}/><button onClick={()=>remove(i)}>×</button></div>)}{files.length<5&&<label className="addThumb">＋<input type="file" accept="image/*" multiple onChange={addFiles}/></label>}</div>}<button className="primary wide" disabled={!files.length||busy} onClick={identify}>{busy?'Analyse en cours…':'🌿 Analyser la plante'} <span>→</span></button><div className="privacy">🔒 Vos photos sont utilisées uniquement pour l’analyse.</div></section><section className="sideInfo"><div className="infoCard"><b>📸 Conseils pour une meilleure analyse</b><ul><li>Photographiez les feuilles nettement</li><li>Ajoutez une vue générale de la plante</li><li>Évitez les photos trop sombres</li><li>Ajoutez plusieurs vues de la plante si nécessaire</li></ul></div><div className="infoCard green"><b>🧠 Comment ça marche ?</b><p>VégéScan envoie vos images au moteur de reconnaissance végétale puis affiche les espèces les plus probables et leur niveau de confiance.</p></div></section></div></div>}
function Result({busy,files,result,setPage,mode,corrections,setCorrections}) {
  const [editing,setEditing]=useState(false);
  const [species,setSpecies]=useState('');
  const [cultivar,setCultivar]=useState('');
  const [note,setNote]=useState('');
  const correction=corrections.find(c=>c.analysisId===result?.analysisId);
  const saveCorrection=async()=>{
    const item={
      analysisId:result.analysisId||`${Date.now()}`,
      original:result.scientificName,
      originalCommon:result.commonName||result.bestMatch,
      correctedSpecies:species.trim(),
      cultivar:cultivar.trim(),
      note:note.trim(),
      validatedBy:'professionnel',
      date:new Date().toISOString()
    };
    const next=[item,...corrections.filter(c=>c.analysisId!==item.analysisId)].slice(0,100);
    setCorrections(next);
    localStorage.setItem('vegescan_corrections',JSON.stringify(next));
    const key=sessionStorage.getItem('vegescan_pro_key')||'';
    try{
      if(key){
        const r=await fetch('/api/corrections',{method:'POST',headers:{'Content-Type':'application/json','x-vegescan-pro-key':key},body:JSON.stringify({analysisId:item.analysisId,suggestedName:item.original,scientificName:item.correctedSpecies,cultivar:item.cultivar,note:item.note})});
        if(!r.ok)throw Error();
      }
    }catch(e){console.warn('Correction non synchronisée',e.message)}
    setEditing(false);
  };

  if(busy) return <div className="content"><section className="panel loading"><div className="loader">🌿</div><h2>Analyse de votre plante…</h2><p>Comparaison avec les espèces végétales connues.</p></section></div>;
  if(!result) return <div className="content"><section className="panel"><h2>Aucun résultat</h2><button className="primary" onClick={()=>setPage('scan')}>Nouvelle analyse →</button></section></div>;

  return <div className="content">
    <div className="resultGrid">
      <section className="panel resultMain">
        <div className="resultPhoto">{files[0]&&<img src={URL.createObjectURL(files[0])}/>}<span>✓ Analyse terminée</span></div>
        {result.error ? <>
          <span className="badge danger">⚠️ Erreur</span>
          <h2>{result.bestMatch}</h2>
          <p>{result.scientificName}</p>
        </> : <>
          <span className="badge">🌿 Résultat principal</span>
          <h2>{correction?.correctedSpecies||result.commonName||result.bestMatch}</h2>
          <em>{correction?.cultivar ? `${correction.correctedSpecies} '${correction.cultivar}'` : result.scientificName}</em>
          {correction&&<div className="validated">✓ Identification corrigée et validée par un professionnel</div>}
          <div className="confidence">
            <div><b>{Math.round((result.score||0)*100)}%</b><small>confiance Pl@ntNet</small></div>
            <div className="bar"><span style={{width:`${Math.round((result.score||0)*100)}%`}}></span></div>
          </div>
          <div className="chips"><span>🌱 Végétal</span><span>🔎 Pl@ntNet</span>{mode==='pro'&&<span>🌾 Mode professionnel</span>}</div>
          <div className="resultActions">
            <button className="secondary" onClick={()=>setPage('scan')}>📷 Nouvelle analyse</button>
            {mode==='pro'&&<button className="primary compact" onClick={()=>{setSpecies(correction?.correctedSpecies||result.scientificName||'');setCultivar(correction?.cultivar||'');setNote(correction?.note||'');setEditing(true)}}>✏️ Corriger l’identification</button>}
          </div>
          {editing&&<div className="correctionBox">
            <div><span className="badge">🌾 VALIDATION PROFESSIONNELLE</span><h3>Corriger cette identification</h3><p>Pl@ntNet fournit une proposition. Votre correction devient une identification validée dans VégéScan.</p></div>
            <label>Espèce correcte<input value={species} onChange={e=>setSpecies(e.target.value)} placeholder="Ex. Acer palmatum"/></label>
            <label>Variété / cultivar (facultatif)<input value={cultivar} onChange={e=>setCultivar(e.target.value)} placeholder="Ex. Dissectum"/></label>
            <label>Note professionnelle (facultatif)<textarea value={note} onChange={e=>setNote(e.target.value)} placeholder="Pourquoi cette identification ?"/></label>
            <div className="correctionButtons"><button className="secondary" onClick={()=>setEditing(false)}>Annuler</button><button className="primary compact" disabled={!species.trim()} onClick={saveCorrection}>✓ Valider la correction</button></div>
          </div>}
        </>}
      </section>
      <section className="panel alternatives">
        <h3>Autres résultats possibles</h3>
        {(result.alternatives||[]).slice(1,5).map((x,i)=><div className="alt" key={i}><div><b>{x.common||x.name||'Espèce possible'}</b><small>{x.name||''}</small></div><strong>{Math.round((x.score||0)*100)}%</strong></div>)}

      </section>
    </div>
  </div>;
}
function Advice({result,files,onSubmit}){const [name,setName]=useState('');const [email,setEmail]=useState('');const [question,setQuestion]=useState('');const [topic,setTopic]=useState('Identification');const [photo,setPhoto]=useState(null);const submit=()=>{if(!question.trim()||!email.trim())return;onSubmit({id:`adv-${Date.now()}`,name:name.trim()||'Visiteur',email:email.trim(),question:question.trim(),topic,plant:result?.scientificName||result?.bestMatch||'',confidence:result?.score||0,hasPhoto:!!photo,date:new Date().toISOString(),status:'nouvelle'});};return <div className="content"><div className="adviceGrid"><section className="panel adviceMain"><span className="badge">💬 CONSEIL VÉGÉTAL</span><h2>Une question sur votre plante ?</h2><p className="muted">Envoyez votre question avec une photo si besoin. Un professionnel pourra vous répondre avec des conseils adaptés.</p>{result&&!result.error&&<div className="contextCard"><b>🌿 Analyse associée</b><span>{result.commonName||result.bestMatch} · {Math.round((result.score||0)*100)}% de confiance</span></div>}<label>Votre nom<input value={name} onChange={e=>setName(e.target.value)} placeholder="Prénom ou nom"/></label><label>Votre e-mail <small>pour recevoir la réponse</small><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="vous@exemple.fr"/></label><label>Sujet<select value={topic} onChange={e=>setTopic(e.target.value)}><option>Identification</option><option>Maladie ou ravageur</option><option>Entretien</option><option>Taille</option><option>Plantation / culture</option><option>Autre</option></select></label><label>Votre question<textarea value={question} onChange={e=>setQuestion(e.target.value)} placeholder="Décrivez votre plante et ce que vous souhaitez savoir…"/></label><label className="photoAdvice">📷 Ajouter une photo complémentaire<input type="file" accept="image/*" onChange={e=>setPhoto(e.target.files?.[0]||null)}/><small>{photo?photo.name:'Facultatif'}</small></label><button className="primary wide" disabled={!question.trim()||!email.trim()} onClick={submit}>Envoyer ma demande <span>→</span></button><p className="privacy">Vos coordonnées servent uniquement à traiter votre demande de conseil.</p></section><aside className="adviceSide"><div className="infoCard green"><b>👨‍🌾 Une réponse personnalisée</b><p>Votre demande peut être reliée à votre analyse VégéScan afin de donner au professionnel le maximum de contexte.</p></div><div className="infoCard"><b>💡 Pour obtenir une bonne réponse</b><ul><li>Décrivez les symptômes ou votre objectif</li><li>Indiquez l'emplacement de la plante</li><li>Ajoutez une photo nette si nécessaire</li><li>Précisez ce que vous avez déjà essayé</li></ul></div></aside></div></div>}
function AdviceInbox({requests,setRequests,corrections,mode}){const [selected,setSelected]=useState(null),[reply,setReply]=useState(''),[key,setKey]=useState(()=>sessionStorage.getItem('vegescan_pro_key')||''),[auth,setAuth]=useState(false),[busy,setBusy]=useState(false);const load=async()=>{setBusy(true);try{const r=await fetch('/api/advice',{headers:{'x-vegescan-pro-key':key}});if(!r.ok)throw Error();const data=await r.json();setRequests(data);sessionStorage.setItem('vegescan_pro_key',key);setAuth(true)}catch{setAuth(false)}finally{setBusy(false)}};const send=async()=>{if(!selected||!reply.trim())return;try{const r=await fetch(`/api/advice/${selected}/reply`,{method:'POST',headers:{'Content-Type':'application/json','x-vegescan-pro-key':key},body:JSON.stringify({reply})});if(!r.ok)throw Error();const saved=await r.json();setRequests(x=>x.map(i=>i.id===saved.id?saved:i));setReply(saved.reply||'')}catch{const next=requests.map(i=>i.id===selected?{...i,reply:reply.trim(),status:'répondue'}:i);setRequests(next);localStorage.setItem('vegescan_advice_requests',JSON.stringify(next))}};if(mode!=='pro')return <div className="content"><section className="panel"><span className="badge">🌿 ESPACE PROFESSIONNEL</span><h2>Conseils à traiter</h2><p className="muted">Passez en mode Professionnel pour accéder aux demandes.</p></section></div>;if(!auth)return <div className="content"><section className="panel"><span className="badge">🌾 ACCÈS PROFESSIONNEL</span><h2>Ouvrir les demandes</h2><p className="muted">Entrez votre code professionnel pour accéder aux demandes reçues.</p><label>Code professionnel<input type="password" value={key} onChange={e=>setKey(e.target.value)} placeholder="Code fourni par VégéScan"/></label><button className="primary compact" disabled={!key||busy} onClick={load}>{busy?'Vérification…':'Accéder aux demandes →'}</button><p className="privacy">Le code est conservé uniquement dans cette session.</p></section></div>;const open=requests.find(r=>r.id===selected);return <div className="content"><div className="inboxHead"><div><span className="badge">🌾 ESPACE PROFESSIONNEL</span><h2>Conseils à traiter</h2><p className="muted">Demandes reçues des particuliers.</p></div><div className="inboxCount">{requests.filter(r=>r.status==='nouvelle').length}<small>nouvelles</small></div></div><div className="inboxGrid"><section className="panel requestList">{requests.length===0?<div className="empty">💬 Aucune demande pour le moment.</div>:requests.map(r=><button className={`requestItem ${selected===r.id?'selected':''}`} key={r.id} onClick={()=>{setSelected(r.id);setReply(r.reply||'')}}><div><b>{r.name}</b><span>{r.topic}</span><small>{new Date(r.date).toLocaleString('fr-FR')}</small></div><strong>{r.status==='nouvelle'?'NOUVELLE':'RÉPONDUE'}</strong></button>)}</section><section className="panel requestDetail">{open?<><span className="badge">{open.topic}</span><h3>{open.name}</h3><p className="muted">{open.email}</p>{open.plant&&<div className="contextCard"><b>🌿 Plante associée</b><span>{open.plant} · {Math.round((open.confidence||0)*100)}%</span></div>}<div className="questionBubble"><b>Question</b><p>{open.question}</p></div><label>Votre réponse<textarea value={reply} onChange={e=>setReply(e.target.value)} placeholder="Écrivez votre conseil…"/></label><button className="primary compact" disabled={!reply.trim()} onClick={send}>✉️ Envoyer la réponse</button></>:<div className="empty">Sélectionnez une demande.</div>}</section></div><div className="panel correctionStats"><b>🌱 Vos corrections professionnelles</b><span>{corrections.length} identification(s) validée(s)</span></div></div>}
function Garden(){return <div className="content"><div className="cards culture">{cultures.map(v=><div className="cultureCard" key={v[1]}><span>{v[0]}</span><div><b>{v[1]}</b><small>{v[2]}</small><small>{v[3]}</small></div></div>)}</div></div>}
createRoot(document.getElementById('root')).render(<App/>);
