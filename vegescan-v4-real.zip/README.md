# VégéScan V4 — base réelle
Cette version contient un frontend mobile-first et un serveur Express pour connecter la reconnaissance réelle Pl@ntNet.

## Reconnaissance réelle
Créer une clé API Pl@ntNet puis lancer:
PLANTNET_API_KEY="votre_cle" npm run server

En production, la clé doit rester côté serveur. L'application appelle /api/identify.

## Installation
npm install
npm run build
PLANTNET_API_KEY="..." npm run server

Le serveur sert le dossier dist.

## Important
Les calendriers potager/lunaire inclus sont une base d'interface et doivent être enrichis avec des données agronomiques/locales avant commercialisation.
