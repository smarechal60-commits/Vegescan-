import express from "express";
import multer from "multer";
const app=express(),upload=multer({storage:multer.memoryStorage()});
const PORT=process.env.PORT||3000, KEY=process.env.PLANTNET_API_KEY;
app.post("/api/identify",upload.single("image"),async(req,res)=>{
 if(!KEY)return res.status(503).json({error:"PLANTNET_API_KEY missing"});
 if(!req.file)return res.status(400).json({error:"image missing"});
 const form=new FormData();
 form.append("images",new Blob([req.file.buffer],{type:req.file.mimetype}),req.file.originalname);
 form.append("organs","auto");
 const url=`https://my-api.plantnet.org/v2/identify/all?lang=fr&nb-results=5&api-key=${encodeURIComponent(KEY)}`;
 try{
  const r=await fetch(url,{method:"POST",body:form});
  const d=await r.json();
  if(!r.ok)return res.status(r.status).json(d);
  const top=d.results?.[0];
  res.json({bestMatch:d.bestMatch,scientificName:top?.species?.scientificName||d.bestMatch,commonName:top?.species?.commonNames?.[0]||d.bestMatch,score:top?.score||0,alternatives:(d.results||[]).slice(0,5).map(x=>({name:x.species?.scientificName,common:x.species?.commonNames?.[0],score:x.score}))});
 }catch(e){res.status(500).json({error:"upstream_error"})}
});
app.use(express.static("dist"));
app.listen(PORT,()=>console.log(`VégéScan server on ${PORT}`));