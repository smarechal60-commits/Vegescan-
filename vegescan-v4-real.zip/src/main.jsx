import React,{useState} from "react";
import{createRoot}from"react-dom/client";
import"./style.css";
const veg=[
["🥕","Carotte","Semis mars → juillet","Récolte juin → novembre"],
["🍅","Tomate","Semis février → avril","Récolte juin → octobre"],
["🥬","Salade","Semis février → septembre","Récolte avril → novembre"],
["🫛","Haricot","Semis mai → juillet","Récolte juillet → octobre"],
["🥒","Courgette","Semis avril → juin","Récolte juin → octobre"],
["🥔","Pomme de terre","Plantation mars → mai","Récolte juin → septembre"]
];
function App(){
 const [tab,setTab]=useState("home"),[mode,setMode]=useState("particulier"),[photo,setPhoto]=useState(null),[res,setRes]=useState(null),[busy,setBusy]=useState(false),[history,setHistory]=useState([]);
 async function identify(file){
  setPhoto(URL.createObjectURL(file));setBusy(true);setTab("scan");
  const fd=new FormData();fd.append("image",file);
  try{const r=await fetch("/api/identify",{method:"POST",body:fd});if(!r.ok)throw Error();const d=await r.json();setRes(d);setHistory(h=>[d,...h])}
  catch{setRes({bestMatch:"Reconnaissance indisponible",scientificName:"Configurez l'API Pl@ntNet dans le serveur.",score:0,commonName:"—",error:true})}
  finally{setBusy(false)}
 }
 return <div className="app">
 {tab==="home"&&<><header><div className="leaf">🌿</div><div className="logo">Végé<span>Scan</span></div><p>Votre compagnon végétal au quotidien</p></header>
 <div className="mode"><button className={mode==="particulier"?"on":""} onClick={()=>setMode("particulier")}>🏡 Particulier</button><button className={mode==="pro"?"on":""} onClick={()=>setMode("pro")}>🌾 Professionnel</button></div>
 <section className="today"><div><small>AUJOURD'HUI</small><h2>Que faire au jardin ?</h2><p>🌱 Surveiller les semis et adapter l'arrosage aux conditions météo.</p></div><b>🌔</b></section>
 <div className="grid"><Card i="🔎" t="Reconnaître" s="Plante, adventice ou légume" f={()=>setTab("scanHome")}/><Card i="🥕" t="Mon potager" s="Semis, plantations, récoltes" f={()=>setTab("garden")}/><Card i="🌙" t="Lune" s="Calendrier lunaire" f={()=>setTab("moon")}/><Card i="📅" t="Calendrier" s="Que semer et planter ?" f={()=>setTab("calendar")}/></div>
 <div className="tip"><b>💡 Conseil</b><p>Photographiez plusieurs parties d'une même plante pour améliorer l'identification.</p></div><Nav setTab={setTab}/></>}
 {tab==="scanHome"&&<Page t="Reconnaître" back={()=>setTab("home")}><div className="panel center"><div className="big">📷</div><h2>Identifiez un végétal</h2><p>Ajoutez une photo claire. La version réelle peut envoyer jusqu'à 5 images de la même plante à l'IA.</p><label className="btn">📸 Prendre une photo<input type="file" accept="image/jpeg,image/png,image/*" capture="environment" onChange={e=>e.target.files[0]&&identify(e.target.files[0])}/></label></div></Page>}
 {tab==="scan"&&<Page t="Identification" back={()=>setTab("scanHome")}><div className="panel center">{photo&&<img className="photo" src={photo}/>} {busy?<><div className="spinner">⌕</div><h2>Analyse en cours…</h2><p>Recherche des espèces les plus probables.</p></>:res&&<><div className="pill">{res.error?"⚠️ Configuration à terminer":"✓ Identification probable"}</div><h1>{res.commonName||res.bestMatch}</h1><em>{res.scientificName||res.bestMatch}</em>{res.score>0&&<div className="score"><b>{Math.round(res.score*100)}%</b><span>confiance</span></div>}<p>{res.error?"Le moteur de reconnaissance est prêt à être connecté avec votre clé API.":"Résultat fourni par le moteur de reconnaissance végétale."}</p><button className="btn" onClick={()=>setTab("scanHome")}>📷 Nouvelle photo</button></>}</div></Page>}
 {tab==="garden"&&<Page t="Mon potager" back={()=>setTab("home")}><div className="panel"><h2>🥕 Calendrier du potager</h2>{veg.map(v=><div className="row" key={v[1]}><span>{v[0]}</span><div><b>{v[1]}</b><small>{v[2]}<br/>{v[3]}</small></div></div>)}</div></Page>}
 {tab==="calendar"&&<Page t="Calendrier" back={()=>setTab("home")}><div className="panel"><h2>🌱 Travaux du potager</h2><div className="task">🥕 <b>Semer</b><span>Carottes, radis, salades selon la période et la région.</span></div><div className="task">🌿 <b>Planter</b><span>Salades et légumes adaptés à la saison.</span></div><div className="task">🧺 <b>Récolter</b><span>Consultez les fiches de chaque culture.</span></div><p className="note">Les périodes doivent être adaptées à la région, au climat et aux conditions locales.</p></div></Page>}
 {tab==="moon"&&<Page t="Calendrier lunaire" back={()=>setTab("home")}><div className="panel"><div className="moonhero">🌔<div><b>Calendrier lunaire</b><small>Semis • plantations • récoltes</small></div></div>{["🌑 Nouvelle Lune","🌒 Premier croissant","🌓 Premier quartier","🌕 Pleine Lune","🌗 Dernier quartier"].map(x=><div className="moonrow" key={x}><span>{x.split(" ")[0]}</span><b>{x.substring(3)}</b></div>)}<p className="note">Le calendrier lunaire est présenté comme un repère traditionnel de jardinage, et ne remplace pas les conditions agronomiques réelles.</p></div></Page>}
 </div>
}
function Card({i,t,s,f}){return <button className="card" onClick={f}><span>{i}</span><b>{t}</b><small>{s}</small></button>}
function Page({t,back,children}){return <><div className="top"><button onClick={back}>‹</button><h2>{t}</h2></div>{children}</>}
function Nav({setTab}){return <nav><button onClick={()=>setTab("home")}>⌂<small>Accueil</small></button><button onClick={()=>setTab("garden")}>🥕<small>Potager</small></button><button className="main" onClick={()=>setTab("scanHome")}>＋</button><button onClick={()=>setTab("moon")}>🌙<small>Lune</small></button><button onClick={()=>setTab("calendar")}>📅<small>Calendrier</small></button></nav>}
createRoot(document.getElementById("root")).render(<App/>);