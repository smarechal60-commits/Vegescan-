# VégéScan v5 — interface moderne

Version modernisée de VégéScan avec :
- interface responsive moderne
- reconnaissance Pl@ntNet
- jusqu’à 5 photos d’une même plante
- résultats alternatifs et score de confiance
- module d’observation maladies & ravageurs
- potager, calendrier, lune et météo (modules d’interface)

## Déploiement Render
Build Command :
`mkdir -p app && unzip -o vegescan-modern-v5.zip -d app && cd app/vegescan-v5 && npm install && npm run build`

Start Command :
`cd app/vegescan-v5 && node server/index.mjs`

Variable d’environnement : `PLANTNET_API_KEY`
