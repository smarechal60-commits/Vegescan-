-- VégéScan : base de données Supabase
create table if not exists public.advice_requests (
  id text primary key,
  name text not null default 'Visiteur',
  email text not null,
  question text not null,
  topic text not null default 'Autre',
  plant text not null default '',
  confidence numeric not null default 0,
  status text not null default 'nouvelle',
  reply text,
  date timestamptz not null default now(),
  replied_at timestamptz
);
create index if not exists advice_requests_date_idx on public.advice_requests(date desc);

create table if not exists public.corrections (
  id text primary key,
  analysis_id text not null,
  suggested_name text not null default '',
  scientific_name text not null,
  cultivar text not null default '',
  note text not null default '',
  date timestamptz not null default now()
);
create index if not exists corrections_date_idx on public.corrections(date desc);

-- Le serveur utilise la clé service_role : ne jamais la mettre dans le navigateur.


-- V18 : communauté persistante et stockage des photos
create table if not exists public.community_posts (
  id text primary key,
  pseudo text not null,
  plant text not null,
  description text not null default '',
  visibility text not null default 'public',
  photo_name text not null default '',
  photo_url text not null default '',
  date timestamptz not null default now()
);
create index if not exists community_posts_date_idx on public.community_posts(date desc);
insert into storage.buckets (id, name, public) values ('vegescan-community','vegescan-community',true) on conflict (id) do nothing;
